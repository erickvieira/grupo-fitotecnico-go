<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Tevent
 */

?>
	</div><!-- #content -->

	<?php if ( Tevent::getOption( 'footer_logo' ) || Tevent::getOption( 'copyright_text' ) ) : ?>
		<footer id="colophon" class="site-footer bg-darker u-PaddingTop100 u-sm-PaddingTop30 u-PaddingBottom100 u-sm-PaddingBottom30" role="contentinfo">
			<div class="container text-center text-sm">
				<?php
				if ( Tevent::getOption( 'footer_logo' ) && wp_get_attachment_image_url( $footer_logo, 'full' ) ) {
					printf( '<img class="u-MarginBottom50 u-sm-MarginBottom30" src="%s" alt="%s">',
						esc_url( wp_get_attachment_image_url( $footer_logo, 'full' ) ),
						esc_attr( get_bloginfo( 'description' ) )
						);
				}
				?>

				<div class="social-links sl-default light-link solid-link circle-link colored-hover">
					<?php tevent_social_links(); ?>
				</div>
				<p class="u-MarginBottom5 u-MarginTop20"><?php echo wp_kses_data( Tevent::getOption( 'copyright_text' ) ); ?></p>
			</div>
		</footer><!-- #colophon -->
	<?php endif; ?>

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
